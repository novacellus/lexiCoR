library(testthat)
library(lexR)

test_check("lexR")